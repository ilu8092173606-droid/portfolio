<?php
return array (
  'username' => 'bittu-bh',
  'password_hash' => '$2y$12$wrnKzj2ZnSW6Aek4X.JQvODCM/AbPYAA9LM7F2x3KcsCQ86CrBNum',
  'document_password_hash' => '$2y$12$oQ.7mC.vI8M2.sISxFes7ep0kGdeCg6kZwArpejHydFDlhUlwjrJW',
);
